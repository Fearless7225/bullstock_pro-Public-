
import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {
    let urlString: String
    func makeUIView(context: Context) -> WKWebView { WKWebView() }
    func updateUIView(_ uiView: WKWebView, context: Context) {
        if let url = URL(string: urlString) {
            uiView.load(URLRequest(url: url))
        }
    }
}

@main
struct BullStockApp: App {
    let appURL = "https://YOUR_DEPLOYED_BULLSTOCK_URL"
    var body: some Scene {
        WindowGroup {
            WebView(urlString: appURL).ignoresSafeArea()
        }
    }
}
