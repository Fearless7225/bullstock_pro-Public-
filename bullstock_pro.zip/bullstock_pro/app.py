
import streamlit as st
import pandas as pd
import numpy as np
from scoring import (
    score_revenue_growth, score_debt_ratio, score_peg, score_dcf,
    moat_composite, total_score, wacc, simple_dcf
)
from data_providers import choose_provider

st.set_page_config(page_title="BullStock — Pro MVP", layout="wide")
st.title("🐂 BullStock — Scoring & Valuation")

st.sidebar.header("Data Source")
provider = st.sidebar.radio("Provider", ["FMP", "YF"], help="FMP = FinancialModelingPrep, YF = Yahoo Finance")
api_key = st.sidebar.text_input("FMP API Key (if using FMP)", type="password")

tickers_csv = st.file_uploader("Upload tickers CSV (col: Ticker) or use bundled Top 100.", type=["csv"])
if tickers_csv:
    df_tickers = pd.read_csv(tickers_csv)
else:
    df_tickers = pd.read_csv("data/top100_sp500.csv")

st.sidebar.header("Economic Moat (defaults)")
brand = st.sidebar.slider("Brand & Pricing", 0, 10, 6)
barriers = st.sidebar.slider("Barriers to Entry", 0, 10, 7)
switching = st.sidebar.slider("Switching Costs", 0, 10, 6)
network = st.sidebar.slider("Network Effect", 0, 10, 6)
scale = st.sidebar.slider("Economies of Scale", 0, 10, 8)

st.sidebar.header("Quality Defaults")
default_fcf_score = st.sidebar.slider("FCF Score default", 0, 10, 8)
default_ni_score  = st.sidebar.slider("Net Income Score default", 0, 10, 8)

st.sidebar.header("DCF & WACC (shared for run)")
ttm_fcf = st.sidebar.number_input("TTM FCF (absolute)", value=1_000_000.0, step=100000.0)
growth_years = st.sidebar.number_input("Projection years", value=5, step=1)
growth_rate = st.sidebar.number_input("FCF Growth %", value=10.0, step=1.0)/100.0
terminal_growth = st.sidebar.number_input("Terminal Growth %", value=2.5, step=0.5)/100.0
cost_equity = st.sidebar.number_input("Cost of Equity %", value=10.0, step=0.5)/100.0
cost_debt = st.sidebar.number_input("Cost of Debt %", value=5.0, step=0.5)/100.0
tax_rate = st.sidebar.number_input("Tax Rate %", value=25.0, step=1.0)/100.0
equity_val = st.sidebar.number_input("Equity Value (mkt cap)", value=10_000_000_000.0, step=100000000.0)
debt_val = st.sidebar.number_input("Debt Value", value=1_000_000_000.0, step=10000000.0)
shares_out = st.sidebar.number_input("Shares Outstanding", value=1_000_000_000.0, step=1000000.0)
net_cash = st.sidebar.number_input("Net Cash (cash - debt)", value=0.0, step=1000000.0)

wacc_calc = wacc(cost_equity, cost_debt, tax_rate, equity_val, debt_val)
st.sidebar.metric("WACC (calc)", f"{wacc_calc*100:.2f}%")

run = st.button("Run Scoring")

if run:
    if provider == "FMP" and not api_key:
        st.error("Enter FMP API key in the sidebar or switch provider to YF.")
        st.stop()
    if provider == "FMP":
        import os
        os.environ["FMP_API_KEY"] = api_key

    rows = []
    progress = st.progress(0.0, text="Fetching data...")
    for i, t in enumerate(df_tickers["Ticker"].tolist()):
        snap = choose_provider(t, provider)

        intrinsic = simple_dcf(
            ttm_fcf=ttm_fcf,
            growth_years=int(growth_years),
            growth_rate=growth_rate,
            terminal_growth=terminal_growth,
            discount_rate=wacc_calc,
            shares_outstanding=shares_out,
            net_cash=net_cash
        )
        price = snap.get("Price", np.nan)
        dcf_upside = ((intrinsic - price) / price * 100) if (price and not np.isnan(price) and price != 0 and not np.isnan(intrinsic)) else np.nan
        dcf_s = score_dcf(dcf_upside)

        rev_s = score_revenue_growth(snap.get("Revenue Growth YoY (%)"))
        debt_s = score_debt_ratio(snap.get("Debt/Equity"))
        peg_s = score_peg(snap.get("PEG Ratio"))
        moat_s = moat_composite(brand, barriers, switching, network, scale)
        fcf_s = default_fcf_score
        ni_s  = default_ni_score

        total = total_score(rev_s, debt_s, fcf_s, ni_s, moat_s, dcf_s, peg_s)

        row = {
            "Ticker": t, "Company": snap.get("Company"), "Price": price,
            "PEG Ratio": snap.get("PEG Ratio"), "PEG Score": peg_s,
            "Revenue Growth YoY (%)": snap.get("Revenue Growth YoY (% )") if "Revenue Growth YoY (% )" in snap else snap.get("Revenue Growth YoY (%)"),
            "Revenue Score": rev_s,
            "Debt/Equity": snap.get("Debt/Equity"), "Debt Score": debt_s,
            "Moat Subscores (Brand,Barriers,Switching,Network,Scale)": f"{brand},{barriers},{switching},{network},{scale}",
            "Moat Score": moat_s,
            "WACC (%)": wacc_calc*100, "DCF Intrinsic / Share": intrinsic,
            "DCF Upside (%)": dcf_upside, "DCF Score": dcf_s,
            "FCF Score": fcf_s, "Net Income Score": ni_s,
            "Total Score": total, "Moat Notes": ""
        }
        rows.append(row)
        progress.progress((i+1)/len(df_tickers), text=f"Processed {i+1}/{len(df_tickers)}")

    df = pd.DataFrame(rows)
    st.success("Done.")
    st.dataframe(df, use_container_width=True)

    st.download_button("Download Excel", df.to_excel(index=False), "bullstock_scores.xlsx")
    st.download_button("Download CSV", df.to_csv(index=False).encode("utf-8"), "bullstock_scores.csv")
else:
    st.info("Set provider + inputs, then click **Run Scoring**.")
    st.caption("Upload your own tickers CSV (column: Ticker).")
