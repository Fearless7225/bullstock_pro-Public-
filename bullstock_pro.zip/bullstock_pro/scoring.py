
import numpy as np
import pandas as pd
def score_revenue_growth(yoy_pct):
    if pd.isna(yoy_pct): return np.nan
    if yoy_pct > 20: return 10
    if yoy_pct > 10: return 8
    if yoy_pct > 5:  return 6
    if yoy_pct > 0:  return 4
    return 0
def score_debt_ratio(debt_to_equity):
    if pd.isna(debt_to_equity): return np.nan
    if debt_to_equity < 0.5: return 10
    if debt_to_equity < 1.0: return 7
    if debt_to_equity < 2.0: return 4
    return 0
def score_peg(peg):
    if pd.isna(peg): return np.nan
    if peg < 1:  return 10
    if peg < 2:  return 6
    if peg < 3:  return 3
    return 0
def score_dcf(upside_pct):
    if pd.isna(upside_pct): return np.nan
    if upside_pct > 30: return 10
    if upside_pct > 20: return 8
    if upside_pct > 10: return 6
    if upside_pct > 0:  return 4
    return 0
def moat_composite(brand, barriers, switching, network, scale):
    subs = [brand, barriers, switching, network, scale]
    if any(pd.isna(x) for x in subs): 
        return np.nan
    return round(sum(subs) / 5, 2)
def wacc(cost_of_equity, cost_of_debt, tax_rate, equity_value, debt_value):
    E, D = equity_value, debt_value
    V = E + D if (E + D) != 0 else 1
    return (E/V)*cost_of_equity + (D/V)*cost_of_debt*(1 - tax_rate)
def simple_dcf(ttm_fcf, growth_years, growth_rate, terminal_growth, discount_rate, shares_outstanding, net_cash=0):
    fcf_list = []
    fcf = ttm_fcf
    for _ in range(growth_years):
        fcf *= (1 + growth_rate)
        fcf_list.append(fcf)
    pv = sum(fcf_list[i] / ((1 + discount_rate) ** (i+1)) for i in range(len(fcf_list)))
    terminal_fcf = fcf_list[-1] * (1 + terminal_growth)
    tv = terminal_fcf / (discount_rate - terminal_growth) if discount_rate > terminal_growth else 0
    pv_terminal = tv / ((1 + discount_rate) ** growth_years)
    equity_value = pv + pv_terminal + net_cash
    intrinsic_per_share = equity_value / shares_outstanding if shares_outstanding else np.nan
    return intrinsic_per_share
def total_score(rev_s, debt_s, fcf_s, ni_s, moat_s, dcf_s, peg_s,
                quality_w=0.20, valuation_dcf_w=0.60, valuation_peg_w=0.40):
    parts = [rev_s, debt_s, fcf_s, ni_s, moat_s, dcf_s, peg_s]
    if any(pd.isna(x) for x in parts): 
        return np.nan
    total = (quality_w*rev_s + quality_w*debt_s + quality_w*fcf_s +
             quality_w*ni_s  + quality_w*moat_s  +
             valuation_dcf_w*dcf_s + valuation_peg_w*peg_s)
    return round(total, 2)
