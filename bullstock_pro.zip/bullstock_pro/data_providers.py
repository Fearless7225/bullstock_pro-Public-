
import os, numpy as np, pandas as pd, requests
from dotenv import load_dotenv
load_dotenv()
FMP_KEY = os.getenv("FMP_API_KEY", "")
def get_fmp_snapshot(ticker: str) -> dict:
    base = "https://financialmodelingprep.com/api/v3"
    try:
        profile = requests.get(f"{base}/profile/{ticker}?apikey={FMP_KEY}", timeout=20).json()
        key = requests.get(f"{base}/key-metrics-ttm/{ticker}?apikey={FMP_KEY}", timeout=20).json()
        ratios = requests.get(f"{base}/ratios-ttm/{ticker}?apikey={FMP_KEY}", timeout=20).json()
    except Exception:
        profile, key, ratios = [], [], []
    out = {"Ticker": ticker}
    out["Company"] = (profile or [{}])[0].get("companyName", "")
    out["Price"] = (profile or [{}])[0].get("price", np.nan)
    out["PEG Ratio"] = (key or [{}])[0].get("pegRatioTTM", np.nan)
    rg = (key or [{}])[0].get("revenueGrowthTTM", None)
    out["Revenue Growth YoY (%)"] = (rg*100) if rg is not None else np.nan
    out["Debt/Equity"] = (ratios or [{}])[0].get("debtEquityRatioTTM", np.nan)
    out["TTM FCF"] = (key or [{}])[0].get("freeCashFlowPerShareTTM", np.nan)
    out["Shares Outstanding"] = (profile or [{}])[0].get("volAvg", np.nan)
    return out
def get_yf_snapshot(ticker: str) -> dict:
    try:
        import yfinance as yf
        t = yf.Ticker(ticker)
        info = t.fast_info if hasattr(t, "fast_info") else {}
        stats = t.info if hasattr(t, "info") else {}
        return {
            "Ticker": ticker,
            "Company": stats.get("longName", ""),
            "Price": (info.get("last_price") if info else np.nan),
            "PEG Ratio": stats.get("pegRatio", np.nan),
            "Revenue Growth YoY (%)": np.nan,
            "Debt/Equity": stats.get("debtToEquity", np.nan),
            "TTM FCF": np.nan,
            "Shares Outstanding": stats.get("sharesOutstanding", np.nan)
        }
    except Exception:
        return {"Ticker": ticker}
def choose_provider(ticker: str, provider: str):
    provider = (provider or "FMP").upper()
    if provider == "YF":
        return get_yf_snapshot(ticker)
    return get_fmp_snapshot(ticker)
