
# 🐂 BullStock — Pro MVP

Live scoring & valuation web app (Streamlit). Fetches data (FMP or Yahoo Finance), applies your quality + valuation + 5‑part Economic Moat model, and exports results.

## Quick Start
pip install -r requirements.txt
streamlit run app.py

- Provider **FMP** → add your API key in the sidebar (or `.env`).
- Provider **YF** → no key needed.

## iPhone (no laptop after deploy)
Deploy on Streamlit Cloud, open the URL in Safari, then Share ▸ Add to Home Screen.
